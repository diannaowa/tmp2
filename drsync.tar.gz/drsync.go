package main

import (
	"bytes"
	"flag"
	"fmt"
	log "github.com/Sirupsen/logrus"
	"github.com/diannaowa/go-fsevents"
	"io/ioutil"
	"os"
	"os/exec"
	"os/signal"
	"path"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"syscall"
	"time"
)

var (
	Delete  bool
	Params  string
	wg      sync.WaitGroup
	Reg     *regexp.Regexp //exclude files matching PATTERN
	Exclude string         //exclude files matching PATTERN for resync cmd
)

type FileEvent struct {
	FilePath string
	IsDelete bool
}

type FileInotify struct {
	c        chan *FileEvent
	stop     chan struct{}
	delEvent map[string]int
	mux      sync.Mutex
}

func (fi *FileInotify) HandleEvents(watcher *fsevents.Watcher, watchDir string) {
	watcher.StartAll()
	go watcher.Watch()
	fi.SendDelEvent()
	log.Info("Waiting for events...")

	for {
		list := watcher.ListDescriptors()
		log.Println(list)
		select {
		case event := <-watcher.Events:
			if path.Clean(event.Path) == "." || (Reg != nil && Reg.MatchString(path.Clean(event.Path))) {
				break
			}

			if event.IsDirCreated() == true {
				log.Debugf("Directory created:", path.Clean(event.Path))

				watcher.RecursiveAdd(path.Clean(event.Path), 0)
				watcher.AddDescriptor(path.Clean(event.Path), 0)
				fi.PushEvent(event.Path, false)
			}

			if event.IsDirRemoved() == true && Delete {
				p := path.Clean(event.Path)

				log.Debugf("Directory removed:%s", p)
				if err := watcher.RemoveDescriptor(p); err != nil {
					log.Error(err)
					break
				}
				if !fi.DoesPathExist(getBasedir(p)) {
					break
				}
				//fi.PushEvent(p, true)
				fi.MergeEvent(event.Path)

			}

			if event.IsFileCreated() == true {
				log.Debugf("File created & sync: %s", path.Clean(event.Path))

				fi.PushEvent(event.Path, false)
			}

			if event.IsFileRemoved() == true && Delete {

				log.Debugf("File removed: %s", path.Clean(event.Path))

				if !fi.DoesPathExist(getBasedir(event.Path)) {
					break
				}
				//fi.PushEvent(event.Path, true)
				fi.MergeEvent(event.Path)
			}

			if event.IsFileCloseWrite() == true {
				log.Debugf("File close write: %s", path.Clean(event.Path))
				fi.PushEvent(event.Path, false)
			}

			break
		case err := <-watcher.Errors:
			log.Error(err)
			break
		}
	}
}

func (fi *FileInotify) DoesPathExist(path string) bool {
	if _, err := os.Stat(path); err == nil {
		return true
	}
	return false
}

func (fi *FileInotify) PushEvent(path string, isDelete bool) {
	pevent := &FileEvent{
		FilePath: path,
		IsDelete: isDelete,
	}
	fi.c <- pevent
}

// Merge events to one event witch happend in 1s.
func (fi *FileInotify) MergeEvent(path string) {

	fi.mux.Lock()
	defer fi.mux.Unlock()
	baseDir := getBasedir(path) + "/"
	if fi.delEvent[baseDir] == 0 {
		fi.delEvent[baseDir] = 1
	}

}

func (fi *FileInotify) SendDelEvent() {

	go func() {
		for {
			time.Sleep(100 * time.Millisecond)
			fi.mux.Lock()
			for k, _ := range fi.delEvent {
				if fi.DoesPathExist(k) {
					fi.PushEvent(k, true)
				}
				delete(fi.delEvent, k)
			}
			fi.mux.Unlock()
		}
	}()
}

type FileSynchronize struct {
	watchDir       string
	destDir        string
	c              chan *FileEvent
	concurrencyNum int
	stop           chan struct{}
}

func (fs *FileSynchronize) InitSync() {

	for i := 0; i < fs.concurrencyNum; i++ {
		log.Infof("Start %d goroutine.", i)
		go func() {
			defer wg.Done()
			for {
				select {
				case event := <-fs.c:
					basedir := getBasedir(path.Clean(event.FilePath)) //tmp/foo
					if event.IsDelete {
						basedir = event.FilePath
					}

					dest := fs.destDir + strings.TrimPrefix(basedir, getBasedir(fs.watchDir))
					if event.FilePath == fs.watchDir {
						dest = fs.destDir
					}

					fs.FileSync(event.FilePath, dest)
					break
				case <-fs.stop:
					log.Info("Stop goroutine....")
					return
				}

			}
		}()
	}
}

func (fs *FileSynchronize) FileSync(filePath string, dest string) error {

	p := []string{Params}

	if Delete {
		p = append(p, "--delete")
	}

	if Exclude != "" {
		p = append(p, "--exclude-from="+Exclude)
	}
	p = append(p, filePath, dest)
	//time.Sleep(time.Millisecond * 100)
	log.Debugf("Info src :%s dest:%s", filePath, dest)

	//cmd := exec.Command("/usr/bin/rsync", Params, delFlag, filePath, dest)
	cmd := exec.Command("/usr/bin/rsync", p...)

	stdout := &bytes.Buffer{}
	stderr := &bytes.Buffer{}

	cmd.Stdout = stdout
	cmd.Stderr = stderr
	err := cmd.Run()
	if err != nil {
		os.Stderr.WriteString(fmt.Sprintf("%s\n", err.Error()))
		log.Error(stderr)
	} else {
		log.Debug(stdout)
	}

	return err
}

func getBasedir(dir string) string {

	return filepath.ToSlash(filepath.Dir(dir))
}

func init() {
	Formatter := new(log.TextFormatter)
	Formatter.TimestampFormat = "02-01-2006 15:04:05"
	Formatter.FullTimestamp = true
	log.SetFormatter(Formatter)

}

func main() {

	dir := flag.String("W", "./", "Must specify directory to watch.")
	dest := flag.String("D", "", "Must specify destination directory.")
	concurrency := flag.Int("C", 1, " Number of workers spawned for sync files.")
	params := flag.String("P", "-avu", "Parameters for rsync command.")
	ex := flag.String("exclude-from", "", "Read exclude patterns from FILE")
	debug := flag.Bool("debug", false, "Print debug info.")
	del := flag.Bool("delete", false, "Delete extraneous files from dest dirs")
	help := flag.Bool("h", false, "Print help info")
	flag.Parse()

	if *help {
		flag.Usage()
		os.Exit(0)
	}

	if *debug {
		log.SetLevel(log.DebugLevel)
	}

	watchDir := *dir
	concurrencyNum := *concurrency
	destDir := *dest

	Delete = *del
	Params = *params

	pathCh := make(chan *FileEvent)
	stop := make(chan struct{})
	sigs := make(chan os.Signal, 1)
	signal.Notify(sigs, syscall.SIGTERM, syscall.SIGINT)

	log.Println("Sync files from " + watchDir + " to " + destDir + "....")

	if !strings.HasSuffix(watchDir, "/") {
		watchDir += "/"
	}
	if !strings.HasSuffix(destDir, "/") {
		destDir += "/"
	}

	//exclude file
	if *ex != "" {
		Exclude = *ex
		dat, err := ioutil.ReadFile(Exclude)
		if err != nil {
			panic(err)
		}

		var re []string
		s := strings.Split(string(dat), "\n")

		for _, item := range s {

			if item == "" {
				continue
			}
			if strings.Contains(item, "*") {
				re = append(re, strings.Replace(item, "*", ".*", -1))
			} else {
				re = append(re, item+"/", "/"+item+"$")
			}
		}
		//log.Println(strings.Join(re, "|"))
		Reg = regexp.MustCompile(strings.Join(re, "|"))
	}

	options := &fsevents.WatcherOptions{
		Recursive:       true,
		UseWatcherFlags: true,
	}

	inotifyFlags := fsevents.Delete | fsevents.Create | fsevents.IsDir | fsevents.MovedTo | fsevents.MovedFrom | fsevents.CloseWrite

	w, err := fsevents.NewWatcher(watchDir, inotifyFlags, options)
	if err != nil {
		log.Fatal(err)
	}

	fs := &FileSynchronize{
		watchDir:       watchDir,
		destDir:        destDir,
		concurrencyNum: concurrencyNum,
		c:              pathCh,
		stop:           stop,
	}
	// First time

	fs.FileSync(watchDir, destDir)

	go fs.InitSync()

	fi := &FileInotify{
		c:        pathCh,
		stop:     stop,
		delEvent: make(map[string]int),
	}
	go fi.HandleEvents(w, watchDir)
	wg.Add(concurrencyNum)
	<-sigs
	close(stop)
	wg.Wait()
}

