./gradlew clean build

sudo docker login -u admin -p admin123 nexus.hlp.fun:5001

sudo docker build -t nexus.hlp.fun:5001/wrapper:0.0.${GO_PIPELINE_COUNTER} .

sudo docker push nexus.hlp.fun:5001/wrapper:0.0.${GO_PIPELINE_COUNTER}

