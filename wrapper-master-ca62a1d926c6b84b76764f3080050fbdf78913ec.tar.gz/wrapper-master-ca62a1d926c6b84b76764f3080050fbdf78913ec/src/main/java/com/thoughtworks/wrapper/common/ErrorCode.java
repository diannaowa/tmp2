package com.thoughtworks.wrapper.common;

import com.fasterxml.jackson.annotation.JsonValue;

import java.util.HashMap;

public enum ErrorCode {
    UNAUTHORIZED(401, "unauthorized.");

    private final int code;

    private final String message;

    ErrorCode(int code, String message) {
        this.code = code;
        this.message = message;
    }

    public int getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }

    @JsonValue
    public ErrorMessage toErrorMessage() {
        return new ErrorMessage(code, message, new HashMap<>());
    }

}
