package com.thoughtworks.wrapper.controllers;

import com.thoughtworks.wrapper.service.JenkinsPathBuilder;
import com.thoughtworks.wrapper.service.JenkinsService;
import com.thoughtworks.wrapper.service.ResponseWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.HandlerMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping(value = "/job")
public class Controllers {

    private final JenkinsService jenkinsService;

    @Value("#{'${need.redirect}'.split(',')}")
    private List<String> needRedirect;

    @Autowired
    private JenkinsPathBuilder builder;

    public Controllers(JenkinsService jenkinsService) {
        this.jenkinsService = jenkinsService;
    }


    @RequestMapping(value = "/", method = RequestMethod.GET)
    public String hello() {
        return "hello";
    }

    @GetMapping(value = "/{pipelineName}/{buildNumber:\\d+}/")
    public ResponseEntity getBuild(@PathVariable("pipelineName") String pipelineName,
                                   HttpServletRequest request,
                                   HttpServletResponse response) throws IOException, InterruptedException {

        return getResponseEntity(pipelineName, request, response);
    }

    @GetMapping(value = "/{tenant}/job/{pipelineName}/{buildNumber:\\d+}/")
    public ResponseEntity getTenantBuild(@PathVariable("tenant") String tenant,
                                         @PathVariable("pipelineName") String pipelineName,
                                         HttpServletRequest request,
                                         HttpServletResponse response) throws IOException, InterruptedException {
        return getResponseEntity(tenant, pipelineName, request, response);
    }

    @GetMapping(value = "/{pipelineName}/{buildNumber:\\d+}/{operation:'${jenkins.operations}'}/**")
    public ResponseEntity getBuildInfo(@PathVariable("pipelineName") String pipelineName,
                                       HttpServletRequest request,
                                       HttpServletResponse response) throws IOException, InterruptedException {
        return getResponseEntity(pipelineName, request, response);
    }

    @GetMapping(value = "/{tenant}/job/{pipelineName}/{buildNumber:\\d+}/{operation:'${jenkins.operations}'}/**")
    public ResponseEntity getTenantBuildInfo(@PathVariable("tenant") String tenant,
                                             @PathVariable("pipelineName") String pipelineName,
                                             HttpServletRequest request,
                                             HttpServletResponse response) throws IOException, InterruptedException {
        return getResponseEntity(tenant, pipelineName, request, response);
    }

    @RequestMapping(value = "/job/{pipelineName}/buildHistory/ajax", method = RequestMethod.POST)
    public void ajaxPost(@PathVariable("pipelineName") String pipelineName) throws IOException {
        jenkinsService.ajaxPost(pipelineName);
    }

    @RequestMapping(value = "/descriptor/hudson.plugins.gradle.GradleTaskNote/outline", method = RequestMethod.POST)
    public void postOutLine() throws IOException {
        jenkinsService.forwardPostRequest2Jenkins("/descriptor/hudson.plugins.gradle.GradleTaskNote/outline");
    }

    private ResponseEntity getResponseEntity(String tenant,
                                             String pipelineName,
                                             HttpServletRequest request,
                                             HttpServletResponse response) throws IOException, InterruptedException {
        return getResponseEntity(String.format("%s/%s", tenant, pipelineName), request, response);
    }

    private ResponseEntity getResponseEntity(String pipelineName,
                                             HttpServletRequest request,
                                             HttpServletResponse response) throws IOException, InterruptedException {

        String path = (String) request.getAttribute(HandlerMapping.PATH_WITHIN_HANDLER_MAPPING_ATTRIBUTE);

        if (!path.endsWith("/") && needRedirect.stream().anyMatch(s -> path.endsWith(s))) {
            response.sendRedirect(builder.appendSuffix(path));
            return ResponseEntity.status(HttpStatus.MOVED_TEMPORARILY).build();
        }

        ResponseWrapper res = jenkinsService.getJobInformation(pipelineName, path);
        return ResponseEntity.ok().headers(res.getHeaders()).body(res.getBody());
    }
}
