package com.thoughtworks.wrapper.resolver;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import java.util.List;
import java.util.stream.Collectors;

@Configuration
@EnableWebMvc
public class MvcConfig extends WebMvcConfigurerAdapter {

    @Value("${jenkins.service.url}")
    private String jenkinsServerUrl;

    @Value("#{'${jenkins.resource.suffix}'.split(',')}")
    private List<String> jenkinsResourceSuffix;

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {

        List<String> suffixes = jenkinsResourceSuffix.stream().map(s -> s.trim()).collect(Collectors.toList());
        registry.addResourceHandler(suffixes.toArray(new String[suffixes.size()]))
                .addResourceLocations(jenkinsServerUrl);
    }
}
