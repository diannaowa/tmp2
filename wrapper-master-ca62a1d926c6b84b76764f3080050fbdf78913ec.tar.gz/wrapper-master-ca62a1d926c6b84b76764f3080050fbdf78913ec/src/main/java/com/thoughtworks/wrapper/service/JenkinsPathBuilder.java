package com.thoughtworks.wrapper.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
@Slf4j
public class JenkinsPathBuilder {
    private final String jenkinsServerUrl;

    public JenkinsPathBuilder(@Value("${jenkins.service.url}") String jenkinsServerUrl) {
        this.jenkinsServerUrl = jenkinsServerUrl;
    }


    public String byPipelineNameAndNumber(String pipelineName, String number, String finalPath) {
        return String.format("%s/job/%s/%s/%s", jenkinsServerUrl, pipelineName, number, finalPath);
    }

    public String byPipelineName(String pipelineName) {
        return String.format("%s/job/%s", jenkinsServerUrl, pipelineName);
    }

    public String ajaxPost(String pipelineName) {
        return String.format("%s/job/%s/buildHistory/ajax", jenkinsServerUrl, pipelineName);
    }

    public String addHostBeforeURI(String url) {
        return String.format("%s/%s", jenkinsServerUrl, url);
    }

    public String appendSuffix(String path) {
        return String.format("%s/", path);
    }
}
