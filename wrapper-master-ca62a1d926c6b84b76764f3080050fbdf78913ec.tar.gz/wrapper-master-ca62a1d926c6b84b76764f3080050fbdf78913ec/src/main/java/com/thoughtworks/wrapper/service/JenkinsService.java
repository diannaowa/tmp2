package com.thoughtworks.wrapper.service;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.Instant;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Component
@Slf4j
public class JenkinsService {

    private final String jenkinsMountDir;
    private final String jenkinsHomePath;
    private final JenkinsPathBuilder pathBuilder;

    public static final String HEADER = "header";
    public static final String BODY = "body";

    @Value("#{'${elements.to.be.deleted.selectors}'.split(',')}")
    private List<String> selectorsToDelete;

    @Value("${navigator.menu.class}")
    private String navigatorSelector;

    @Value("#{'${navigator.menu.reserve}'.split(',')}")
    private String navigatorMenuReserve;

    @Value("${symbolic.link.expired.seconds}")
    private Long symbolicLinkExpiredInSeconds;

    private Map<String, Instant> symbolicLinks = new HashMap<>();

    public JenkinsService(@Value("${jenkins.master.mount.dir}") String jenkinsMountDir,
                          @Value("${jenkins.home.path}") String jenkinsHomePath,
                          JenkinsPathBuilder pathBuilder) {
        this.pathBuilder = pathBuilder;
        this.jenkinsMountDir = jenkinsMountDir;
        this.jenkinsHomePath = jenkinsHomePath;
    }

    public ResponseWrapper getJobInformation(String pipelineName, String url) throws IOException, InterruptedException {
        return getResultFromJenkins(pipelineName, url);
    }

    public void forwardPostRequest2Jenkins(String url) throws IOException {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpPost post = new HttpPost(pathBuilder.addHostBeforeURI(url));
        CloseableHttpResponse response = httpClient.execute(post);
    }

    private ResponseWrapper getResultFromJenkins(String pipelineName, String url) throws IOException, InterruptedException {
        if (!createSymbolLink(pipelineName)) {
            throw new IOException();
        }

        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet(pathBuilder.addHostBeforeURI(url));
        CloseableHttpResponse response = httpClient.execute(httpGet);

        HttpHeaders headers = new HttpHeaders();
        Arrays.stream(response.getAllHeaders()).forEach(h -> headers.add(h.getName(), h.getValue()));

        return new ResponseWrapper(removeForbiddenTags(EntityUtils.toString(response.getEntity()), pathBuilder.addHostBeforeURI(url)), headers);
    }

    private boolean createSymbolLink(String pipelineName) throws IOException, InterruptedException {
        List<String> pipelinePath = Arrays.asList(pipelineName.split("/"));

        String linkName = pipelineName;
        if (pipelinePath.size() > 2 || pipelinePath.size() == 0) {
            log.error("[pipelineName error] pipeline path is {}", pipelineName);
            return false;
        } else if (pipelinePath.size() == 2) {
            linkName = pipelinePath.get(0);
        }

        Path target = Paths.get(jenkinsMountDir + "/" + linkName);
        Path newLink = Paths.get(jenkinsHomePath + "/" + linkName);

        if (!Files.exists(newLink) && Files.createSymbolicLink(newLink, target) == null) {
            return false;
        }

        synchronized (symbolicLinks) {
            symbolicLinks.put(newLink.toString(), Instant.now().plusSeconds(symbolicLinkExpiredInSeconds));
        }

        return true;
    }

    public void ajaxPost(String pipelineName) throws IOException {
        CloseableHttpClient httpClient = HttpClients.createDefault();
        HttpPost post = new HttpPost(pathBuilder.ajaxPost(pipelineName));
        CloseableHttpResponse response = httpClient.execute(post);
        int statusCode = response.getStatusLine().getStatusCode();
        if (statusCode != HttpStatus.OK.value()) {
            log.info("[ajax post] failed. status code{}", response.getStatusLine().getStatusCode());
        }
    }

    private String removeForbiddenTags(String html, String url) {
        Document page = Jsoup.parse(html, url);

        selectorsToDelete.forEach(s -> {
                    Elements element = page.select(s);
                    if (element != null) {
                        element.remove();
                    }
                }
        );

        page.select(navigatorSelector).stream().filter(s -> !navigatorMenuReserve.contains(s.select(".task-link").html())).forEach( s -> s.remove());

        return page.outerHtml();
    }

    @Scheduled(fixedRate = 5000)
    public void deleteExpiredSymbolicLink() {
        synchronized(symbolicLinks) {

            Map<String, Instant> expired = symbolicLinks.entrySet().stream()
                    .filter(e -> e.getValue().isBefore(Instant.now()))
                    .filter(e -> {
                        try {
                            Files.delete(Paths.get(e.getKey()));
                            return true;
                        } catch (IOException e1) {
                            log.error("[delete failed] delete symbol link {} failed", e.getKey());
                            return false;
                        }
                    })
                    .collect(Collectors.toMap(e -> e.getKey(), e -> e.getValue()));

            symbolicLinks.keySet().removeAll(expired.keySet());
        }
    }
}
