package com.thoughtworks.wrapper.service;

import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.http.HttpHeaders;

@Data
@AllArgsConstructor
public class ResponseWrapper {
    private String body;
    private HttpHeaders headers;
}
