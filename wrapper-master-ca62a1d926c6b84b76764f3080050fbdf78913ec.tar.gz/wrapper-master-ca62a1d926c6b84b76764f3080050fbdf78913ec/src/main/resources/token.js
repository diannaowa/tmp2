
function send(href) {
  $.ajax({
    headers: {
      "token": "12345678"
    },
    url: href,
    complete: function () {
      return true;
    },
    error: function () {
      return false;
    },
  });

}

$(function () {
  $("a").click(function () {
    var href = this.href
    this.href = "#"
    send(href)
  });
});
